package com.sendmail.send_email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SendEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
